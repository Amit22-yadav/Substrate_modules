#[frame_support::storage_alias]
type Ident = CustomStorage<Hello, u32>;

fn main() {}
