#[frame_support::storage_alias]
type NoUnderscore = StorageValue<_, u32>;

fn main() {}
