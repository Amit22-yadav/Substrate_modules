#[frame_support::storage_alias]
type Ident = StorageValue<hello::World, u32>;

fn main() {}
