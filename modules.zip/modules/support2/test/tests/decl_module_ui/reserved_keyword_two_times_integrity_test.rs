frame_support::decl_module! {
	pub struct Module<T: Config> for enum Call where origin: T::Origin, system=self {
		fn integrity_test() {}

		fn integrity_test() {}
	}
}
