frame_support::decl_module! {
	pub struct Module<T: Config> for enum Call where origin: T::Origin, system=self {
		fn on_initialize() -> Weight {
			0
		}

		fn on_initialize() -> Weight {
			0
		}
	}
}

fn main() {}
