#[frame_support::pallet]
mod foo;

fn main() {
}
