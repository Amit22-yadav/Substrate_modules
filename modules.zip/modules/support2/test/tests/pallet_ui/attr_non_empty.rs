#[frame_support::pallet [foo]]
mod foo {
}

fn main() {
}
